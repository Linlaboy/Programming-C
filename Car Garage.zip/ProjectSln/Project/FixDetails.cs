﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    [Serializable]
    public class FixDetails
    {

        public string Mechanic { get; set; }
        public string Rotor { get; set; }
        public string EccentricShaft { get; set; }
        public string BackGear { get; set; }
        public string HousingBack { get; set; }
        public string HousingRotor { get; set; }
        public string MiddleHousing { get; set; }
        public string GearFront { get; set; }
        public string FrontHousing { get; set; }
        public string SparkPlug { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public string DisplayText
        {
            get
            {
                return $"{Mechanic} : {StartDate} : {EndDate}";
            }
        }
    }
}
