﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.DML
{
    public class InvoiceModel
    {
        public int Order { get; set; }
        public DateTime ReceiptDate1 { get; set; }
        public DateTime ReceiptDate2 { get; set; }
        public List<OrderItem> Items { get; set; }
        public string Comments { get; set; }
    }
}
