﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    public class JsonHelper
    {
        private static string _FileName = @"d:\Cardata.json";
        public static BindingList<CardataClass> ReadObjects()
        {
            if (File.Exists(_FileName))
            {
                BindingList<CardataClass> CardataList
                    = JsonConvert.DeserializeObject<BindingList<CardataClass>>
                        (File.ReadAllText(JsonHelper._FileName));

                return CardataList;
            }
            else
            {
                return new BindingList<CardataClass>();

            }
        }
        public static void WriteObject(IList<CardataClass> CardataList)
        {
            //open file stream
            using (StreamWriter file = File.CreateText(JsonHelper._FileName))
            {
                JsonSerializer serializer = new JsonSerializer();
                //serialize object directly into file stream
                serializer.Serialize(file, CardataList);
            }
        }
    }
}
