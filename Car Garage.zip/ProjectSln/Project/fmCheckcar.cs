﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsApp1;

namespace Project
{
    public partial class fmCheckcar : Form
    {
        BindingList<FixDetails> FixList = new BindingList<FixDetails>();


        private CardataClass empSelected;
        public fmCheckcar()
        {
            InitializeComponent();
            lsboxFixDetails.DisplayMember = "DisplayText";
        }

        public fmCheckcar(CardataClass empSelected) : this()
        {
            this.empSelected = empSelected;
            txtFixDetails.Text = empSelected.DisplayText;
        }


        private void fmEmployeeJobList_Load(object sender, EventArgs e)
        {
            cmbMechanic.Items.Add("ช่าง อัษฏ เบี้ยมุขดา");
            cmbMechanic.Items.Add("ช่าง ณัฐภพ พวงทอง");
            cmbMechanic.Items.Add("ช่าง เจตน์ สระพรหม");
            cmbMechanic.Items.Add("ช่าง ณัฐพจน์ วิวัฒนเจริญชัย");
            cmbMechanic.SelectedIndex = 0;
        }

        private void btnSavefixdetails_Click(object sender, EventArgs e)
        {

            FixDetails newFix = new FixDetails();
            newFix.Mechanic = cmbMechanic.SelectedItem.ToString();
            newFix.Rotor = txtRotor.Text;
            newFix.EccentricShaft = txtEccentricShaft.Text;
            newFix.BackGear = txtBackGear.Text;
            newFix.HousingBack = txtHousingBack.Text;
            newFix.HousingRotor = txtHousingRotor.Text;
            newFix.MiddleHousing = txtMiddleHousing.Text;
            newFix.GearFront = txtGearFront.Text;
            newFix.FrontHousing = txtFrontHousing.Text;
            newFix.SparkPlug = txtSparkPlug.Text;
            newFix.StartDate = dtPkStartDate.Value;
            newFix.EndDate = dtPkEndDate.Value;

            empSelected.FixList.Add(newFix);

            lsboxFixDetails.DataSource = null;
            lsboxFixDetails.DisplayMember = "DisplayText";
            lsboxFixDetails.ValueMember = "No";
            lsboxFixDetails.DataSource = empSelected.FixList;
        }

       
    }
}
