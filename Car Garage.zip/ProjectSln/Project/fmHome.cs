﻿using Project.DSL;
using QuestPDF.Fluent;
using QuestPDF.Previewer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsApp1;

namespace Project
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnMaximize_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
            {
                WindowState = FormWindowState.Maximized;
                btnMaximize.IconChar = FontAwesome.Sharp.IconChar.WindowRestore;
            }
            else
            {
                WindowState = FormWindowState.Normal;
            }
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void btnCardata_Click(object sender, EventArgs e)
        {
            AddFormToPanel(new fmCardata());
        }

        private void btnCheckCar_Click(object sender, EventArgs e)
        {
            AddFormToPanel(new fmCheckcar());
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            AddFormToPanel(new fmOrder());
        }

        private void btnInvoice_Click(object sender, EventArgs e)
        {
            var filePath = "Receipt.pdf";

            var model = InvoiceDocumentDataSource.GetInvoiceDetails();
            var document = new InvoiceDocument(model);
            document.GeneratePdf(filePath);

            Process.Start("explorer.exe", filePath);
        }
        private void AddFormToPanel(Form formChild)
        {
            if (panelRight.Controls.Count > 0)
            {
                var formActive = (Form)panelRight.Controls[0];
                formActive.Close();
            }
            formChild.TopLevel = false;
            formChild.FormBorderStyle = FormBorderStyle.None;
            formChild.Dock = DockStyle.Fill;
            panelRight.Controls.Add(formChild);
            panelRight.Tag = formChild;
            formChild.BringToFront();
            formChild.Show();
        }
    }
}
