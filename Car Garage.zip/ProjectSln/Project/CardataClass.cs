﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    [Serializable]
    public class CardataClass
    {
        public string No { get; set; }
        public string Brand { get; set; }
        public string Passcode { get; set; }
        public string CarColor { get; set; }
        public string CarSegment { get; set; }
        public List<FixDetails> FixList = new List<FixDetails>();
        public string DisplayText
        {
            get { return No + " : " + Brand; }
        }

    }
}
