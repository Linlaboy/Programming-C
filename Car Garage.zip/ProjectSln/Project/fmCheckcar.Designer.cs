﻿namespace Project
{
    partial class fmCheckcar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label13 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtRotor = new System.Windows.Forms.TextBox();
            this.txtEccentricShaft = new System.Windows.Forms.TextBox();
            this.txtBackGear = new System.Windows.Forms.TextBox();
            this.txtHousingBack = new System.Windows.Forms.TextBox();
            this.txtHousingRotor = new System.Windows.Forms.TextBox();
            this.txtMiddleHousing = new System.Windows.Forms.TextBox();
            this.txtGearFront = new System.Windows.Forms.TextBox();
            this.txtFrontHousing = new System.Windows.Forms.TextBox();
            this.txtSparkPlug = new System.Windows.Forms.TextBox();
            this.cmbMechanic = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lsboxFixDetails = new System.Windows.Forms.ListBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtFixDetails = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dtPkStartDate = new System.Windows.Forms.DateTimePicker();
            this.dtPkEndDate = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnSavefixdetails = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Controls.Add(this.lsboxFixDetails);
            this.panel1.Location = new System.Drawing.Point(12, 31);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1240, 657);
            this.panel1.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.label13, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label6, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label9, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label10, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.txtRotor, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtEccentricShaft, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtBackGear, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtHousingBack, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtHousingRotor, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.txtMiddleHousing, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.txtGearFront, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.txtFrontHousing, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.txtSparkPlug, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.cmbMechanic, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label11, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.label12, 0, 7);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 53);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 10;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(633, 600);
            this.tableLayoutPanel1.TabIndex = 33;
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(122, 556);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(72, 28);
            this.label13.TabIndex = 46;
            this.label13.Text = "หัวเทียน";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(63, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(190, 28);
            this.label4.TabIndex = 37;
            this.label4.Text = "ชื่อพนักงานที่รับผิดชอบ";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(125, 76);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 28);
            this.label5.TabIndex = 38;
            this.label5.Text = "โรเตอร์";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(99, 136);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 28);
            this.label6.TabIndex = 39;
            this.label6.Text = "เพลาเยื้องศูนย์";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(93, 196);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(129, 28);
            this.label7.TabIndex = 40;
            this.label7.Text = "เฟืองประกบหลัง";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(108, 256);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(99, 28);
            this.label8.TabIndex = 41;
            this.label8.Text = "เฮาส์ซิงหลัง";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(98, 316);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(119, 28);
            this.label9.TabIndex = 42;
            this.label9.Text = "เฮาส์ซิงโรเตอร์";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(104, 376);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(107, 28);
            this.label10.TabIndex = 43;
            this.label10.Text = "เฮาส์ซิงกลาง";
            // 
            // txtRotor
            // 
            this.txtRotor.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtRotor.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtRotor.Location = new System.Drawing.Point(319, 73);
            this.txtRotor.Name = "txtRotor";
            this.txtRotor.Size = new System.Drawing.Size(311, 34);
            this.txtRotor.TabIndex = 47;
            // 
            // txtEccentricShaft
            // 
            this.txtEccentricShaft.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtEccentricShaft.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtEccentricShaft.Location = new System.Drawing.Point(319, 133);
            this.txtEccentricShaft.Name = "txtEccentricShaft";
            this.txtEccentricShaft.Size = new System.Drawing.Size(311, 34);
            this.txtEccentricShaft.TabIndex = 48;
            // 
            // txtBackGear
            // 
            this.txtBackGear.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBackGear.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtBackGear.Location = new System.Drawing.Point(319, 193);
            this.txtBackGear.Name = "txtBackGear";
            this.txtBackGear.Size = new System.Drawing.Size(311, 34);
            this.txtBackGear.TabIndex = 49;
            // 
            // txtHousingBack
            // 
            this.txtHousingBack.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtHousingBack.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtHousingBack.Location = new System.Drawing.Point(319, 253);
            this.txtHousingBack.Name = "txtHousingBack";
            this.txtHousingBack.Size = new System.Drawing.Size(311, 34);
            this.txtHousingBack.TabIndex = 50;
            // 
            // txtHousingRotor
            // 
            this.txtHousingRotor.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtHousingRotor.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtHousingRotor.Location = new System.Drawing.Point(319, 313);
            this.txtHousingRotor.Name = "txtHousingRotor";
            this.txtHousingRotor.Size = new System.Drawing.Size(311, 34);
            this.txtHousingRotor.TabIndex = 51;
            // 
            // txtMiddleHousing
            // 
            this.txtMiddleHousing.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtMiddleHousing.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtMiddleHousing.Location = new System.Drawing.Point(319, 373);
            this.txtMiddleHousing.Name = "txtMiddleHousing";
            this.txtMiddleHousing.Size = new System.Drawing.Size(311, 34);
            this.txtMiddleHousing.TabIndex = 52;
            // 
            // txtGearFront
            // 
            this.txtGearFront.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtGearFront.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtGearFront.Location = new System.Drawing.Point(319, 433);
            this.txtGearFront.Name = "txtGearFront";
            this.txtGearFront.Size = new System.Drawing.Size(311, 34);
            this.txtGearFront.TabIndex = 53;
            // 
            // txtFrontHousing
            // 
            this.txtFrontHousing.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtFrontHousing.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtFrontHousing.Location = new System.Drawing.Point(319, 493);
            this.txtFrontHousing.Name = "txtFrontHousing";
            this.txtFrontHousing.Size = new System.Drawing.Size(311, 34);
            this.txtFrontHousing.TabIndex = 54;
            // 
            // txtSparkPlug
            // 
            this.txtSparkPlug.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtSparkPlug.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtSparkPlug.Location = new System.Drawing.Point(319, 553);
            this.txtSparkPlug.Name = "txtSparkPlug";
            this.txtSparkPlug.Size = new System.Drawing.Size(311, 34);
            this.txtSparkPlug.TabIndex = 55;
            // 
            // cmbMechanic
            // 
            this.cmbMechanic.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmbMechanic.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cmbMechanic.FormattingEnabled = true;
            this.cmbMechanic.Items.AddRange(new object[] {
            "ช่าง อัษฏ เบี้ยมุขดา",
            "ช่าง ณัฐภพ พวงทอง",
            "ช่าง เจตน์ สระพรหม",
            "ช่าง ณัฐพจน์ วิวัฒนเจริญชัย"});
            this.cmbMechanic.Location = new System.Drawing.Point(319, 12);
            this.cmbMechanic.Name = "cmbMechanic";
            this.cmbMechanic.Size = new System.Drawing.Size(311, 36);
            this.cmbMechanic.TabIndex = 56;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(92, 496);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(131, 28);
            this.label11.TabIndex = 44;
            this.label11.Text = "เฟืองประกบหน้า";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(107, 436);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 28);
            this.label12.TabIndex = 45;
            this.label12.Text = "เฮาส์ซิงหน้า";
            // 
            // lsboxFixDetails
            // 
            this.lsboxFixDetails.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lsboxFixDetails.FormattingEnabled = true;
            this.lsboxFixDetails.ItemHeight = 23;
            this.lsboxFixDetails.Location = new System.Drawing.Point(642, 9);
            this.lsboxFixDetails.Name = "lsboxFixDetails";
            this.lsboxFixDetails.Size = new System.Drawing.Size(598, 648);
            this.lsboxFixDetails.TabIndex = 32;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel2.Controls.Add(this.txtFixDetails);
            this.panel2.Controls.Add(this.label1);
            this.panel2.ForeColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(12, 28);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(633, 46);
            this.panel2.TabIndex = 33;
            // 
            // txtFixDetails
            // 
            this.txtFixDetails.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtFixDetails.Location = new System.Drawing.Point(260, 9);
            this.txtFixDetails.Name = "txtFixDetails";
            this.txtFixDetails.Size = new System.Drawing.Size(370, 34);
            this.txtFixDetails.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(4, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(250, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "ทะเบียนรถยนตร์กับยี่ห้อรถยนตร์";
            // 
            // dtPkStartDate
            // 
            this.dtPkStartDate.CalendarFont = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.dtPkStartDate.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.dtPkStartDate.Location = new System.Drawing.Point(117, 706);
            this.dtPkStartDate.Name = "dtPkStartDate";
            this.dtPkStartDate.Size = new System.Drawing.Size(210, 34);
            this.dtPkStartDate.TabIndex = 34;
            // 
            // dtPkEndDate
            // 
            this.dtPkEndDate.CalendarFont = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.dtPkEndDate.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.dtPkEndDate.Location = new System.Drawing.Point(438, 707);
            this.dtPkEndDate.Name = "dtPkEndDate";
            this.dtPkEndDate.Size = new System.Drawing.Size(210, 34);
            this.dtPkEndDate.TabIndex = 35;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(12, 708);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 28);
            this.label2.TabIndex = 36;
            this.label2.Text = "วันที่เริ่มงาน";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(333, 711);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 28);
            this.label3.TabIndex = 37;
            this.label3.Text = "วันที่จบงาน";
            // 
            // btnSavefixdetails
            // 
            this.btnSavefixdetails.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnSavefixdetails.Location = new System.Drawing.Point(1083, 697);
            this.btnSavefixdetails.Name = "btnSavefixdetails";
            this.btnSavefixdetails.Size = new System.Drawing.Size(169, 51);
            this.btnSavefixdetails.TabIndex = 38;
            this.btnSavefixdetails.Text = "บันทึกรายการ";
            this.btnSavefixdetails.UseVisualStyleBackColor = true;
            this.btnSavefixdetails.Click += new System.EventHandler(this.btnSavefixdetails_Click);
            // 
            // fmCheckcar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 756);
            this.Controls.Add(this.btnSavefixdetails);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dtPkEndDate);
            this.Controls.Add(this.dtPkStartDate);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "fmCheckcar";
            this.Text = "Car Status ";
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel panel1;
        private ListBox lsboxFixDetails;
        private Panel panel2;
        private TableLayoutPanel tableLayoutPanel1;
        private Label label1;
        private TextBox txtFixDetails;
        private DateTimePicker dtPkStartDate;
        private DateTimePicker dtPkEndDate;
        private Label label2;
        private Label label3;
        private Button btnSavefixdetails;
        private Label label13;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private TextBox txtRotor;
        private TextBox txtEccentricShaft;
        private TextBox txtBackGear;
        private TextBox txtHousingBack;
        private TextBox txtHousingRotor;
        private TextBox txtMiddleHousing;
        private TextBox txtGearFront;
        private TextBox txtFrontHousing;
        private TextBox txtSparkPlug;
        private ComboBox cmbMechanic;
    }
}