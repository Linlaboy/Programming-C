﻿using System;
using System.Collections.Generic;

namespace Project.Models
{
    public partial class Order
    {
        public int No { get; set; }
        public string OrderNo { get; set; } = null!;
        public int? NumberOfRotor { get; set; }
        public int? NumberOfEccentricShaft { get; set; }
        public int? NumberOfBackGear { get; set; }
        public int? NumberOfHousingBack { get; set; }
        public int? NumberOfHousingRotor { get; set; }
        public int? NumberOfMiddleHousing { get; set; }
        public int? NumberOfGearFront { get; set; }
        public int? NumberOfFrontHousing { get; set; }
        public int? NumberOfSparkPlug { get; set; }

        public virtual CheckCar NoNavigation { get; set; } = null!;
        public virtual Receipt OrderNoNavigation { get; set; } = null!;
    }
}
