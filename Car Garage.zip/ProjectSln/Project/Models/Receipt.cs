﻿using System;
using System.Collections.Generic;

namespace Project.Models
{
    public partial class Receipt
    {
        public Receipt()
        {
            Orders = new HashSet<Order>();
        }

        public string OrderNo { get; set; } = null!;
        public int? Quantity { get; set; }
        public int? TotalPrice { get; set; }

        public virtual ICollection<Order> Orders { get; set; }
    }
}
