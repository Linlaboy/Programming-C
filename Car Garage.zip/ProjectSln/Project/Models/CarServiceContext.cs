﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Project.Models
{
    public partial class CarServiceContext : DbContext
    {
        public CarServiceContext()
        {
        }

        public CarServiceContext(DbContextOptions<CarServiceContext> options)
            : base(options)
        {
        }

        public virtual DbSet<CarDatum> CarData { get; set; } = null!;
        public virtual DbSet<CheckCar> CheckCars { get; set; } = null!;
        public virtual DbSet<Order> Orders { get; set; } = null!;
        public virtual DbSet<Receipt> Receipts { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=AISHA\\SQLEXPRESS;Database=Car Service;Trusted_Connection=True;Encrypt=true;TrustServerCertificate=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.UseCollation("Thai_CI_AI");

            modelBuilder.Entity<CarDatum>(entity =>
            {
                entity.HasKey(e => e.No);

                entity.Property(e => e.No).ValueGeneratedNever();

                entity.Property(e => e.Brand)
                    .HasMaxLength(30)
                    .IsFixedLength();

                entity.Property(e => e.CarColor)
                    .HasMaxLength(30)
                    .IsFixedLength();

                entity.Property(e => e.CarSegment)
                    .HasMaxLength(30)
                    .IsFixedLength();

                entity.Property(e => e.Passcode)
                    .HasMaxLength(8)
                    .IsFixedLength();
            });

            modelBuilder.Entity<CheckCar>(entity =>
            {
                entity.HasKey(e => e.No);

                entity.ToTable("CheckCar");

                entity.Property(e => e.No).ValueGeneratedNever();

                entity.Property(e => e.BackGear)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.EccentricShaft)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.EndDate).HasColumnType("date");

                entity.Property(e => e.FrontHousing)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GearFront)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.HousingBack)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.HousingRotor)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Mechanic)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.MiddleHousing)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Rotor)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.SparkPlug)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.StartDate).HasColumnType("date");

                entity.HasOne(d => d.NoNavigation)
                    .WithOne(p => p.CheckCar)
                    .HasForeignKey<CheckCar>(d => d.No)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CheckCar_CarData");
            });

            modelBuilder.Entity<Order>(entity =>
            {
                entity.HasKey(e => e.No);

                entity.ToTable("Order");

                entity.Property(e => e.No).ValueGeneratedNever();

                entity.Property(e => e.NumberOfBackGear).HasColumnName("Number of BackGear");

                entity.Property(e => e.NumberOfEccentricShaft).HasColumnName("Number of EccentricShaft");

                entity.Property(e => e.NumberOfFrontHousing).HasColumnName("Number of FrontHousing");

                entity.Property(e => e.NumberOfGearFront).HasColumnName("Number of GearFront");

                entity.Property(e => e.NumberOfHousingBack).HasColumnName("Number of HousingBack");

                entity.Property(e => e.NumberOfHousingRotor).HasColumnName("Number of HousingRotor");

                entity.Property(e => e.NumberOfMiddleHousing).HasColumnName("Number of MiddleHousing");

                entity.Property(e => e.NumberOfRotor).HasColumnName("Number of Rotor");

                entity.Property(e => e.NumberOfSparkPlug).HasColumnName("Number of SparkPlug");

                entity.Property(e => e.OrderNo)
                    .HasMaxLength(10)
                    .HasColumnName("Order no");

                entity.HasOne(d => d.NoNavigation)
                    .WithOne(p => p.Order)
                    .HasForeignKey<Order>(d => d.No)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Order_CheckCar");

                entity.HasOne(d => d.OrderNoNavigation)
                    .WithMany(p => p.Orders)
                    .HasForeignKey(d => d.OrderNo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Order_Receipt");
            });

            modelBuilder.Entity<Receipt>(entity =>
            {
                entity.HasKey(e => e.OrderNo);

                entity.ToTable("Receipt");

                entity.Property(e => e.OrderNo)
                    .HasMaxLength(10)
                    .HasColumnName("Order no");

                entity.Property(e => e.TotalPrice).HasColumnName("Total Price");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
