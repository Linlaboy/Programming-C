﻿using System;
using System.Collections.Generic;

namespace Project.Models
{
    public partial class CarDatum
    {
        public int No { get; set; }
        public string Brand { get; set; } = null!;
        public string Passcode { get; set; } = null!;
        public string CarColor { get; set; } = null!;
        public string CarSegment { get; set; } = null!;

        public virtual CheckCar CheckCar { get; set; } = null!;
    }
}
