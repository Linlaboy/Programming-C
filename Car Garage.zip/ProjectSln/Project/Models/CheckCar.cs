﻿using System;
using System.Collections.Generic;

namespace Project.Models
{
    public partial class CheckCar
    {
        public int No { get; set; }
        public string Mechanic { get; set; } = null!;
        public string? Rotor { get; set; }
        public string? EccentricShaft { get; set; }
        public string? BackGear { get; set; }
        public string? HousingBack { get; set; }
        public string? HousingRotor { get; set; }
        public string? MiddleHousing { get; set; }
        public string? GearFront { get; set; }
        public string? FrontHousing { get; set; }
        public string? SparkPlug { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        public virtual CarDatum NoNavigation { get; set; } = null!;
        public virtual Order Order { get; set; } = null!;
    }
}
