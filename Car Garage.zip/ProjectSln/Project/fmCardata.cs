using System.ComponentModel;
using System.IO;

namespace Project
{
    public partial class fmCardata : Form
    {
        BindingList<CardataClass> CardataList = new BindingList<CardataClass>();

        CardataClass empSelected = null;
        public fmCardata()
        {
            InitializeComponent();
            lsboxCar.DisplayMember = "DisplayText";
            lsboxCar.ValueMember = "No";
            lsboxCar.DataSource = CardataList;
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            CardataClass newCar = new CardataClass();
            newCar.No = txtNo.Text;
            newCar.Brand = txtBrand.Text;
            newCar.Passcode = txtPasscode.Text;
            newCar.CarColor = txtCarColor.Text;
            newCar.CarSegment = txtCarSegment.Text;

            var hasInList =
                CardataList
                .Where(x => x.No == txtNo.Text)
                .FirstOrDefault();

            if (hasInList == null)
            {
                CardataList.Add(newCar);
            }
            else
            {
                MessageBox.Show("��������ö¹���������",
                    "��سҵ�Ǩ�ͺ",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            JsonHelper.WriteObject(CardataList);
            MessageBox.Show("�ѹ�֡ ���º����", "����͹ !");
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            CardataList = JsonHelper.ReadObjects();
            lsboxCar.DataSource = CardataList;
            
        }

        private void btnSelected_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp;)|*.jpg; *.jpeg; *.gif; *.bmp;";
            if(open.ShowDialog() == DialogResult.OK)
            {
                pbCar.Image = new Bitmap(open.FileName);
            }
        }

        private void lsboxCar_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CardataList.Count > 0 || lsboxCar.SelectedIndex > -1)
            {
                MessageBox.Show(lsboxCar.SelectedValue.ToString());
            }
        }

        private void lsboxCar_MouseDown(object sender, MouseEventArgs e)
        {
            {
                if (e.Button == MouseButtons.Right)
                {
                    int index = lsboxCar.IndexFromPoint(e.Location);
                    if (index != ListBox.NoMatches)
                    {
                        empSelected = (CardataClass)lsboxCar.Items[index];

                        ContextMenuStrip cm = new ContextMenuStrip();
                        cm.Items.Add("�Դ˹�ҵ�ҧ�Ѵ��â����� => �ҹ�Ѻ�Դ�ͺ�����������´ : " + empSelected.No);
                        cm.Items[0].Click += OpenJobList_Click;
                        cm.Items.Add("-");
                        cm.Items.Add("ź");
                        cm.Items[2].Click += DeleteEmployee_Click;

                        lsboxCar.ContextMenuStrip = cm;
                    }
                }
            }
        }

        private void DeleteEmployee_Click(object? sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("��ͧ���ź��������¡��ö¹���ѹ��� ö¹�����·���¹" + " " + empSelected.No,
                "��ͤ����׹�ѹ���ź !",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (dr == DialogResult.Yes)
            {
                CardataList.Remove(empSelected);
                empSelected = null;
            }
        }

        private void OpenJobList_Click(object? sender, EventArgs e)
        {
            fmCheckcar jobForm = new fmCheckcar(empSelected);
            jobForm.Show();
        }

   
    }
}